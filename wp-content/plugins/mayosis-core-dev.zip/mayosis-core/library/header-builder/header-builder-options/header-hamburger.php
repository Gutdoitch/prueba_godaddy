<?php

Mayosis_Option::add_section( 'header_hamburger', array(
	'title'       => __( 'Hamburger Oprions', 'mayosis' ),
	'panel'       => 'header',
) );


Mayosis_Option::add_field( 'mayo_config',  array(
));