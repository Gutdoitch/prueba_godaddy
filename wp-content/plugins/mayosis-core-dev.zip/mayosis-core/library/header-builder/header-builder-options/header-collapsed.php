<?php

Mayosis_Option::add_section( 'header_collapsed', array(
	'title'       => __( 'Sidebar Header', 'mayosis' ),
	'panel'       => 'header',
) );


 Mayosis_Option::add_field( 'mayo_config', array(
        'type'        => 'color',
        'settings'     => 'sidebar_top_color_max',
        'label'       => __( 'Top Part Logo Background', 'mayosis' ),
        'description' => __( 'Change Logo Background', 'mayosis' ),
        'section'     => 'header_collapsed',
        'priority'    => 10,
        'default'     => '#26264d',
        'output' => array(
             array(
                	        'element' => '#mayosis-sidebar .mayosis-sidebar-header',
                	        'property' =>'background-color',
                	        ),
            ),
        'choices' => array(
            'palettes' => array(
                '#28375a',
                '#282837',
                '#5a00f0',
                '#ff6b6b',
                '#c44d58',
                '#ecca2e',
                '#bada55',
            ),
        ),
    ));
    
     Mayosis_Option::add_field( 'mayo_config', array(
        'type'        => 'color',
        'settings'     => 'sidebar_bg_main_ms',
        'label'       => __( 'Sidebar Background', 'mayosis' ),
        'description' => __( 'Change Sidebar Background', 'mayosis' ),
        'section'     => 'header_collapsed',
        'priority'    => 10,
        'default'     => '#ffffff',
        'output' => array(
             array(
                	        'element' => '#mayosis-sidebar,#mayosis-sidebar .sidebar-fixed',
                	        'property' =>'background-color',
                	        ),
            ),
        'choices' => array(
            'palettes' => array(
                '#28375a',
                '#282837',
                '#5a00f0',
                '#ff6b6b',
                '#c44d58',
                '#ecca2e',
                '#bada55',
            ),
        ),
    ));

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'image',
'settings'    => 'sidebar_logo_icon',
'label'       => esc_attr__( 'Sidebar Logo Icon Upload', 'mayosis' ),
'description' => esc_attr__( 'Recommanded Size 40x40px', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => '',
));

                        
Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'default_side_menu',
'label'       => __( 'Default Side Menu', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'expanded',
'priority'    => 10,
'choices'     => array(
	'collapse'   => esc_attr__( 'Collapsed', 'mayosis' ),
	'expanded' => esc_attr__( 'Expanded', 'mayosis' ),
),
));

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'secondary_header',
'label'       => __( 'Secondary Header', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'on',
'priority'    => 10,
'choices'     => array(
	'on'   => esc_attr__( 'Enable', 'mayosis' ),
	'off' => esc_attr__( 'Disable', 'mayosis' ),
),
));
                    

       
                    
Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'icon_in_expanded',
'label'       => __( 'Icon in Expanded Mode', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'on',
'priority'    => 10,
'choices'     => array(
	'on'   => esc_attr__( 'Show', 'mayosis' ),
	'off' => esc_attr__( 'Hide', 'mayosis' ),
),
));
                    
Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'text_in_collapsed',
'label'       => __( 'Text in Collapsed Mode', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'on',
'priority'    => 10,
'choices'     => array(
	'on'   => esc_attr__( 'Show', 'mayosis' ),
	'off' => esc_attr__( 'Hide', 'mayosis' ),
),
));

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'select',
'settings'    => 'shadow_on_sidebar',
'label'       => __( 'Shadow on Sidebar', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'off',
'priority'    => 10,
'choices'     => array(
	'shadowonsidebar'   => esc_attr__( 'Show', 'mayosis' ),
	'off' => esc_attr__( 'Hide', 'mayosis' ),
),
));
                    


   Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'dimensions',
	'settings'    => 'sidebar_main_logo_margin',
	'label'       => esc_html__( 'Main Logo Margin', 'mayosis' ),
	'description' => esc_html__( 'add button padding', 'mayosis' ),
	'section'     => 'header_collapsed',
	'default'     => [
		'margin-top'    => '0',
		'margin-bottom' => '0',
		'margin-left'   => '0',
		'margin-right'  => '0',
	],
	'output' => array(
             array(
                	        'element' => '.sidebar-main-logo img',
                	        
                	        ),
            ),
] );              
  Mayosis_Option::add_field( '',
	array(
		'type'     => 'custom',
		'settings' => 'custom-title-scl',
		'label'    => __( '', 'mayosis' ),
		'section'  => 'header_collapsed',
		'default'  => '<div class="options-title">Sidebar Bottom</div>',
	)
);

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'bottom_social_part_sideheader',
'label'       => __( 'Show Bottom Social', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'off',
'priority'    => 10,
'choices'     => array(
	'on'   => esc_attr__( 'Show', 'mayosis' ),
	'off' => esc_attr__( 'Hide', 'mayosis' ),
),
));

 Mayosis_Option::add_field( 'mayo_config', array(
        'type'        => 'color',
        'settings'     => 'bottom_social_part_bg',
        'label'       => __( 'Bottom Part BG', 'mayosis' ),
        'description' => __( 'Change Social Part BG Color', 'mayosis' ),
        'section'     => 'header_collapsed',
        'priority'    => 10,
        'default'     => '#26264d',
        'output' => array(
             array(
                	        'element' => '#mayosis-sidebar .social-icon-sidebar-header',
                	        'property' =>'background-color',
                	        ),
            ),
        'choices' => array(
            'palettes' => array(
                '#28375a',
                '#282837',
                '#5a00f0',
                '#ff6b6b',
                '#c44d58',
                '#ecca2e',
                '#bada55',
            ),
        ),
    ));
    
     Mayosis_Option::add_field( 'mayo_config', array(
        'type'        => 'color',
        'settings'     => 'bottom_social_part_text',
        'label'       => __( 'Social Icon Color', 'mayosis' ),
        'description' => __( 'Change Social Part icon Color', 'mayosis' ),
        'section'     => 'header_collapsed',
        'priority'    => 10,
        'default'     => '#ffffff',
        'output' => array(
             array(
                	        'element' => '#mayosis-sidebar .social-icon-sidebar-header a',
                	        'property' =>'color',
                	        ),
            ),
        'choices' => array(
            'palettes' => array(
                '#28375a',
                '#282837',
                '#5a00f0',
                '#ff6b6b',
                '#c44d58',
                '#ecca2e',
                '#bada55',
            ),
        ),
    ));
    
     Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'dimensions',
	'settings'    => 'sidebar_btm_part_padding',
	'label'       => esc_html__( 'Bottom Part Padding', 'mayosis' ),
	'description' => esc_html__( 'add bottom part padding', 'mayosis' ),
	'section'     => 'header_collapsed',
	'default'     => [
		'padding-top'    => '0',
		'padding-bottom' => '0',
		'padding-left'   => '0',
		'padding-right'  => '0',
	],
	'output' => array(
             array(
                	        'element' => '.social-icon-sidebar-header',
                	        
                	        ),
            ),
] );              
    
    Mayosis_Option::add_field( '',
	array(
		'type'     => 'custom',
		'settings' => 'custom-title-csbtn',
		'label'    => __( '', 'mayosis' ),
		'section'  => 'header_collapsed',
		'default'  => '<div class="options-title">Collapse Button Options</div>',
	)
);

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'radio-buttonset',
'settings'    => 'collapse_button',
'label'       => __( 'Collapse & expand button', 'mayosis' ),
'section'     => 'header_collapsed',
'default'     => 'off',
'priority'    => 10,
'choices'     => array(
	'on'   => esc_attr__( 'Show', 'mayosis' ),
	'off' => esc_attr__( 'Hide', 'mayosis' ),
),
));
  Mayosis_Option::add_field( 'mayo_config', array(
        'type'        => 'color',
        'settings'     => 'col-btn-color-mm',
        'label'       => __( 'Collapse Button Color', 'mayosis' ),
        'description' => __( 'Change collapse button Color', 'mayosis' ),
        'section'     => 'header_collapsed',
        'priority'    => 10,
        'default'     => '#ffffff',
        'output' => array(
             array(
                	        'element' => '#mayosis-sidebar .burger span,#mayosis-sidebar .burger span::before,#mayosis-sidebar .burger span::after,#mayosis-sidebar .burger.clicked span:before,#mayosis-sidebar .burger.clicked span:after',
                	        'property' =>'background',
                	        ),
            ),
        'choices' => array(
            'palettes' => array(
                '#28375a',
                '#282837',
                '#5a00f0',
                '#ff6b6b',
                '#c44d58',
                '#ecca2e',
                '#bada55',
            ),
        ),
    ));
    
    