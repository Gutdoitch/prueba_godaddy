<?php
Mayosis_Option::add_panel( 'other_options_extra', array(
	'title'       => __( 'Other Options', 'mayosis' ),
	'description' => __( 'Mayosis Other Options.', 'mayosis' ),
	'priority' => '9',
) );

Mayosis_Option::add_section( 'social_options_all', array(
	'title'       => __( 'Social Options', 'mayosis' ),
	'panel'       => 'other_options_extra',

) );

Mayosis_Option::add_section( 'disable_extra_features', array(
	'title'       => __( 'Advanced Features', 'mayosis' ),
	'panel'       => 'other_options_extra',

) );

Mayosis_Option::add_section( 'sticky_notification_bar', array(
	'title'       => __( 'Sticky Notification Bar', 'mayosis' ),
	'panel'       => 'other_options_extra',

) );

Mayosis_Option::add_section( 'mayosis_translation', array(
	'title'       => __( 'String Translation', 'mayosis' ),
	'panel'       => 'other_options_extra',

) );



Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'facebook_url',
	'label'    => __( 'Facebook URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://facebook.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'twitter_url',
	'label'    => __( 'Twitter URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://twitter.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'instagram_url',
	'label'    => __( 'Instagram URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://instagram.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'pinterest_url',
	'label'    => __( 'Pinterest URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://pinterest.com/',
));


Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'youtube_url',
	'label'    => __( 'Youtube URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://youtube.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'linkedin_url',
	'label'    => __( 'Linked In URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://linkedin.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'github_url',
	'label'    => __( 'Github URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://github.io/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'slack_url',
	'label'    => __( 'Slack URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://slack.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'envato_url',
	'label'    => __( 'Envato URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://envato.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'behance_url',
	'label'    => __( 'Behance URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://behance.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'dribbble_url',
	'label'    => __( 'Dribbble URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://dribble.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'vimeo_url',
	'label'    => __( 'Vimeo URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://vimeo.com/',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'     => 'link',
	'settings' => 'spotify_url',
	'label'    => __( 'Spotify URL', 'mayosis' ),
	'section'  => 'social_options_all',
	'default'  => 'https://spotify.com/',
));

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'disable_hit_count',
	'label'       => esc_html__( 'Disable Page View Counter', 'mayosis' ),
	'section'     => 'disable_extra_features',
	'default'     => 'show',
	'priority'    => 10,
	'choices'     => [
		'show'   => esc_html__( 'Enable', 'mayosis' ),
		'hide' => esc_html__( 'Disable', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'disable_font_awesome',
	'label'       => esc_html__( 'Enable/Disable Font Awesome 5', 'mayosis' ),
	'section'     => 'disable_extra_features',
	'default'     => 'hide',
	'priority'    => 10,
	'choices'     => [
		'show'   => esc_html__( 'Enable', 'mayosis' ),
		'hide' => esc_html__( 'Disable', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'disable_google_fonts',
	'label'       => esc_html__( 'Enable/Disable Google Fonts', 'mayosis' ),
	'section'     => 'disable_extra_features',
	'default'     => 'show',
	'priority'    => 10,
	'choices'     => [
		'show'   => esc_html__( 'Enable', 'mayosis' ),
		'hide' => esc_html__( 'Disable', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'enable_notification_bar',
	'label'       => esc_html__( 'Enable Sticky Notificaion Bar', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => 'hide',
	'priority'    => 10,
	'choices'     => [
		'show'   => esc_html__( 'Enable', 'mayosis' ),
		'hide' => esc_html__( 'Disable', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'notification_bar_background_type',
	'label'       => esc_html__( 'Notificaion Bar Background Type', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => 'standard',
	'priority'    => 10,
	'choices'     => [
		'standard'   => esc_html__( 'Standard', 'mayosis' ),
		'gradient' => esc_html__( 'Gradient', 'mayosis' ),
		'custom' => esc_html__( 'Custom', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'background',
	'settings'    => 'notification_bar_standard',
	'label'       => esc_html__( 'Color Options', 'mayosis' ),
	'description' => esc_html__( '', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => [
		'background-color'      => '#483dba',
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.mayosis-standard-bar',
		],
	],
	
	'required'    => array(
            array(
                'setting'  => 'notification_bar_background_type',
                'operator' => '==',
                'value'    => 'standard',
            ),
        ),
] );

Mayosis_Option::add_field( 'mayo_config', array(
    'type'        => 'multicolor',
        'settings'    => 'sticky_bar_gradient',
        'label'       => esc_attr__( 'Sticky bar gradient', 'mayosis' ),
        'section'     => 'sticky_notification_bar',
        'priority'    => 10,
        'choices'     => array(
            'color1'    => esc_attr__( 'Form', 'mayosis' ),
            'color2'   => esc_attr__( 'To', 'mayosis' ),
        ),
        'default'     => array(
            'color1'    => '#1e0046',
            'color2'   => '#1e0064',
        ),
    'required'    => array(
            array(
                'setting'  => 'notification_bar_background_type',
                'operator' => '==',
                'value'    => 'gradient',
            ),
        ),
) );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'code',
	'settings'    => 'notification_custom_css',
	'label'       => esc_html__( 'Custom Css', 'mayosis' ),
	'description' => esc_html__( 'add custom css. you can add gradient code from gradienta.io', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => '',
	'choices'     => [
		'language' => 'css',
	],
	'required'    => array(
            array(
                'setting'  => 'notification_bar_background_type',
                'operator' => '==',
                'value'    => 'custom',
            ),
        ),
] );


Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'color',
	'settings'    => 'notification_btn_bg_color',
	'label'       => __( 'Notification button background Color', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => '#f6d937',
	'output'      => [
		[
			'element' => '.mayosis-sticky-bar-btn',
			'property' => 'background',
		],
	],
] );



Mayosis_Option::add_field( 'mayo_config', [
	'type'     => 'editor',
	'settings' => 'notification_text',
	'label'    => esc_html__( 'Notification Text', 'mayosis' ),
	'default'  => esc_html__( 'Get Big Discount For a Limited time', 'mayosis' ),
	'section'  => 'sticky_notification_bar',
	'priority' => 10,
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'typography',
	'settings'    => 'notification_text_typography',
	'label'       => esc_html__( 'Typography', 'kirki' ),
	'section'     => 'sticky_notification_bar',
	'default'     => [
		'font-family'    => 'Roboto',
		'variant'        => 'regular',
		'font-size'      => '16px',
		'line-height'    => '1.5',
		'letter-spacing' => '0',
		'color'          => '#ffffff',
		'text-transform' => 'none',
		'text-align'     => 'center',
	],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '#mayosis-sticky-bar,.mayosis-sticky-text',
		],
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'     => 'text',
	'settings' => 'notification_btn_text',
	'label'    => esc_html__( 'Button Text', 'mayosis' ),
	'default'  => esc_html__( 'Get the discount', 'mayosis' ),
	'section'  => 'sticky_notification_bar',
	'priority' => 10,
] );
Mayosis_Option::add_field( 'mayo_config', [
	'type'     => 'text',
	'settings' => 'notification_btn_url',
	'label'    => esc_html__( 'Button URL', 'mayosis' ),
	'default'  => esc_html__( '#', 'mayosis' ),
	'section'  => 'sticky_notification_bar',
	'priority' => 10,
] );
Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'typography',
	'settings'    => 'notification_btn_typography',
	'label'       => esc_html__( 'Button Typography', 'kirki' ),
	'section'     => 'sticky_notification_bar',
	'default'     => [
		'font-family'    => 'Roboto',
		'variant'        => 'regular',
		'font-size'      => '16px',
		'line-height'    => '1.5',
		'letter-spacing' => '0',
		'color'          => '#28375a',
		'text-transform' => 'none',
	],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.mayosis-sticky-bar-btn',
		],
	],
] );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'radio-buttonset',
	'settings'    => 'noty_button_target',
	'label'       => esc_html__( 'Notificaion button target', 'mayosis' ),
	'section'     => 'sticky_notification_bar',
	'default'     => 'self',
	'priority'    => 10,
	'choices'     => [
		'blank'   => esc_html__( 'Blank', 'mayosis' ),
		'self' => esc_html__( 'self', 'mayosis' ),
	],
] );

Mayosis_Option::add_field( 'mayo_config', array(
       'type'        => 'dimensions',
        'settings'    => 'pnotification_bar_padding',
        'label'       => esc_attr__( 'Notification Bar Pading', 'mayosis' ),
        'description' => esc_attr__( 'Change Notification Bar Padding', 'mayosis' ),
        'section'     => 'sticky_notification_bar',
        'default'     => array(
            'padding-top'    => '10px',
            'padding-bottom' => '10px',
            'padding-left'   => '0px',
            'padding-right'  => '0px',
        ),
    'output'      => [
		[
			'element' => '.howdydo-box',
		],
	],
) );

Mayosis_Option::add_field( 'mayo_config', array(
       'type'        => 'dimensions',
        'settings'    => 'pnotification_button_padding',
        'label'       => esc_attr__( 'Notification Button Pading', 'mayosis' ),
        'description' => esc_attr__( 'Change Notification Button Padding', 'mayosis' ),
        'section'     => 'sticky_notification_bar',
        'default'     => array(
            'padding-top'    => '6px',
            'padding-bottom' => '6px',
            'padding-left'   => '12px',
            'padding-right'  => '12px',
        ),
    'output'      => [
		[
			'element' => '.mayosis-sticky-bar-btn',
		],
	],
) );

Mayosis_Option::add_field( 'mayo_config', [
	'type'        => 'dimensions',
	'settings'    => 'pnotification_button_radius',
	'section'     => 'sticky_notification_bar',
	'label'       => esc_attr__( 'Button Border Radius', 'mayosis' ),
	'default'     => [
		'top-left-radius'     => '3px',
		'top-right-radius'    => '3px',
		'bottom-left-radius'  => '3px',
		'bottom-right-radius' => '3px',
	],
	'choices'     => [
		'top-left-radius'     => esc_attr__( 'Top Left', 'mayosis' ),
		'top-right-radius'    => esc_attr__( 'Top Right', 'mayosis' ),
		'bottom-left-radius'  => esc_attr__( 'Bottom Left', 'mayosis' ),
		'bottom-right-radius' => esc_attr__( 'Bottom Right', 'mayosis' ),
	],
	'output'    => [
		[
			'property' => 'border',
			'element'  => '.mayosis-sticky-bar-btn',
		],
	]
] );

/****
 * String Translation
 * 
 * ***/
 Mayosis_Option::add_field( 'mayo_config', array(
       'type'        => 'text',
        'settings'    => 'empty_cart_title',
        'label'       => esc_attr__( 'Empty Cart Title', 'mayosis' ),
        'description' => esc_attr__( 'Change empty cart title', 'mayosis' ),
        'default'     => 'Your Cart is Empty',
        'section'     => 'mayosis_translation',
      
) );

 Mayosis_Option::add_field( 'mayo_config', array(
       'type'        => 'text',
        'settings'    => 'empty_cart_subtitle',
        'label'       => esc_attr__( 'Empty Cart Sub Title', 'mayosis' ),
        'description' => esc_attr__( 'Change empty cart Sub title', 'mayosis' ),
        'default'     => 'No Problem, Lets Start Browse',
        'section'     => 'mayosis_translation',
      
) );
 