<?php
/**
 * Custom posts
 */

add_action( 'init', 'mayosis_register_post_types' );
function mayosis_register_post_types() {
    register_post_type('testimonial', array(
        'public' => true,
        'label' => 'Testimonial',
        'menu_icon'           => 'dashicons-welcome-write-blog',
        'labels' => array(
            'name' => 'Testimonial',
            'singular_name' => 'Testimonials',
            'add_new' => 'Add New Testimonial',
        ),
        'supports' => array('title', 'thumbnail'),
        'can_export' => true,
    ));

    register_post_type('slider', array(
        'public' => true,
        'label' => 'Slider',
        'menu_icon'           => 'dashicons-images-alt',
        'labels' => array(
            'name' => 'Slider',
            'singular_name' => 'Sliders',
            'add_new' => 'Add New Slider',
        ),
        'supports' => array('title', 'thumbnail'),
        'can_export' => true,
    ));

    register_post_type('licence',
        array(
            'labels' => array(
                'name' => __( 'License' ),
                'singular_name' => __( 'License' ),
                'add_new' => __( 'Add New' ),
                'add_new_item' => __( 'Add New License' ),
                'edit' => __( 'Edit' ),
                'edit_item' => __( 'Edit License' ),
                'new_item' => __( 'New License' ),
                'view' => __( 'View License' ),
                'view_item' => __( 'View License' ),
                'search_items' => __( 'Search Licenses' ),
                'not_found' => __( 'No Licenses found' ),
                'not_found_in_trash' => __( 'No Licenses found in Trash' ),
                'parent' => __( 'Parent License' ),
            ),
            'public' => true,
            'menu_icon' => 'dashicons-tickets',
            'show_ui' => true,
            'exclude_from_search' => true,
            'hierarchical' => true,
            'supports' => array( 'title'),
            'query_var' => true
        )
    );

}
add_action( 'init', 'mayosis_license_taxonomies', 0 );

function mayosis_license_taxonomies()
{
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name' => _x( 'License Group', 'taxonomy general name' ),
        'singular_name' => _x( 'License Groups', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search Group' ),
        'popular_items' => __( 'Popular Group' ),
        'all_items' => __( 'All License Group' ),
        'parent_item' => __( 'Parent License Group' ),
        'parent_item_colon' => __( 'Parent License Group:' ),
        'edit_item' => __( 'Edit License Group' ),
        'update_item' => __( 'Update License Group' ),
        'add_new_item' => __( 'Add New License Group' ),
        'new_item_name' => __( 'New Recording License Group' ),
    );
    register_taxonomy('license-group',array('licence'), array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'license-group' ),
    ));
}



function short_excerpt($string)
{
    echo substr($string, 0, 210);
}
// Register Custom Post Type Product Template
function mayosis_product_template_cpt() {

    $mproduct_labels = array(
        'name' => _x( 'Product Templates', 'Post Type General Name', 'mayosis' ),
        'singular_name' => _x( 'Product Template', 'Post Type Singular Name', 'mayosis' ),
        'menu_name' => _x( 'Product Templates', 'Admin Menu text', 'mayosis' ),
        'name_admin_bar' => _x( 'Product Template', 'Add New on Toolbar', 'mayosis' ),
        'archives' => __( 'Product Template Archives', 'mayosis' ),
        'attributes' => __( 'Product Template Attributes', 'mayosis' ),
        'parent_item_colon' => __( 'Parent Product Template:', 'mayosis' ),
        'all_items' => __( 'Product Templates', 'mayosis' ),
        'add_new_item' => __( 'Add New Product Template', 'mayosis' ),
        'add_new' => __( 'Add New', 'mayosis' ),
        'new_item' => __( 'New Product Template', 'mayosis' ),
        'edit_item' => __( 'Edit Product Template', 'mayosis' ),
        'update_item' => __( 'Update Product Template', 'mayosis' ),
        'view_item' => __( 'View Product Template', 'mayosis' ),
        'view_items' => __( 'View Product Templates', 'mayosis' ),
        'search_items' => __( 'Search Product Template', 'mayosis' ),
        'not_found' => __( 'Not found', 'mayosis' ),
        'not_found_in_trash' => __( 'Not found in Trash', 'mayosis' ),
        'featured_image' => __( 'Featured Image', 'mayosis' ),
        'set_featured_image' => __( 'Set featured image', 'mayosis' ),
        'remove_featured_image' => __( 'Remove featured image', 'mayosis' ),
        'use_featured_image' => __( 'Use as featured image', 'mayosis' ),
        'insert_into_item' => __( 'Insert into Product Template', 'mayosis' ),
        'uploaded_to_this_item' => __( 'Uploaded to this Product Template', 'mayosis' ),
        'items_list' => __( 'Product Templates list', 'mayosis' ),
        'items_list_navigation' => __( 'Product Templates list navigation', 'mayosis' ),
        'filter_items_list' => __( 'Filter Product Templates list', 'mayosis' ),
         'name_admin_bar'  => __( 'Product', 'mayosis' ),
        
    );
    $mproduct_args = array(
        'label' => __( 'Product Template', 'mayosis' ),
        'description' => __( '', 'mayosis' ),
        'labels' => $mproduct_labels,
        'menu_icon' => '',
        'supports' => array('title', 'editor'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => false,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
       
    );
    register_post_type( 'product_template', $mproduct_args );

}
add_action( 'init', 'mayosis_product_template_cpt', 0 );

// Move the "example_cpt" Custom-Post-Type to be a submenu of the "example_parent_page_id" admin page.
add_action('admin_menu', 'mayosis_fix_product_t_menu', 11);
function mayosis_fix_product_t_menu() {

    // Add "Example CPT" Custom-Post-Type as submenu of the "Example Parent Page" page
    add_submenu_page('mayosis-admin-menu', 'Product Builder', 'Product Builder', 'edit_pages' , 'edit.php?post_type=product_template');
}

// Register Custom Post Type Footer Builder
function mayosis_footer_builder_cpt() {

    $mfooter_labels = array(
        'name' => _x( 'Footer Builders', 'Post Type General Name', 'mayosis' ),
        'singular_name' => _x( 'Footer Template', 'Post Type Singular Name', 'mayosis' ),
        'menu_name' => _x( 'Footer Builder', 'Admin Menu text', 'mayosis' ),
        'name_admin_bar' => _x( 'Footer Template', 'Add New on Toolbar', 'mayosis' ),
        'archives' => __( 'Footer Builder Archives', 'mayosis' ),
        'attributes' => __( 'Footer Builder Attributes', 'mayosis' ),
        'parent_item_colon' => __( 'Parent Footer Builder:', 'mayosis' ),
        'all_items' => __( 'Footer Builder', 'mayosis' ),
        'add_new_item' => __( 'Add New Footer Builder', 'mayosis' ),
        'add_new' => __( 'Add New', 'mayosis' ),
        'new_item' => __( 'New Footer Builder', 'mayosis' ),
        'edit_item' => __( 'Edit Footer Builder', 'mayosis' ),
        'update_item' => __( 'Update Footer Builder', 'mayosis' ),
        'view_item' => __( 'View Footer Builder', 'mayosis' ),
        'view_items' => __( 'View Footer Builder', 'mayosis' ),
        'search_items' => __( 'Search Footer Builder', 'mayosis' ),
        'not_found' => __( 'Not found', 'mayosis' ),
        'not_found_in_trash' => __( 'Not found in Trash', 'mayosis' ),
        'featured_image' => __( 'Featured Image', 'mayosis' ),
        'set_featured_image' => __( 'Set featured image', 'mayosis' ),
        'remove_featured_image' => __( 'Remove featured image', 'mayosis' ),
        'use_featured_image' => __( 'Use as featured image', 'mayosis' ),
        'insert_into_item' => __( 'Insert into Footer Builder', 'mayosis' ),
        'uploaded_to_this_item' => __( 'Uploaded to this Footer Builder', 'mayosis' ),
        'items_list' => __( 'Footer Builder list', 'mayosis' ),
        'items_list_navigation' => __( 'Footer Builder list navigation', 'mayosis' ),
        'filter_items_list' => __( 'Filter Footer Builder list', 'mayosis' ),
    );
    $mfooter_args = array(
        'label' => __( 'Footer Builder', 'mayosis' ),
        'description' => __( '', 'mayosis' ),
        'labels' => $mfooter_labels,
        'menu_icon' => '',
        'supports' => array('title', 'editor'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => false,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type( 'footer_builder', $mfooter_args );

}
add_action( 'init', 'mayosis_footer_builder_cpt', 0 );

// Move the "example_cpt" Custom-Post-Type to be a submenu of the "example_parent_page_id" admin page.
add_action('admin_menu', 'mayosis_fix_footer_t_menu', 11);
function mayosis_fix_footer_t_menu() {

// Add "Example CPT" Custom-Post-Type as submenu of the "Example Parent Page" page
    add_submenu_page('mayosis-admin-menu', 'Footer Builder', 'Footer Builder', 'edit_pages' , 'edit.php?post_type=footer_builder');
}

// Register Custom Post Type EDD Archive Builder
function mayosis_edd_archive_builder_cpt() {

    $marchive_labels = array(
        'name' => _x( 'EDD Archive Builders', 'Post Type General Name', 'mayosis' ),
        'singular_name' => _x( 'EDD Archive Builders', 'Post Type Singular Name', 'mayosis' ),
        'menu_name' => _x( 'EDD Archive Builder', 'Admin Menu text', 'mayosis' ),
        'name_admin_bar' => _x( 'EDD Archive', 'Add New on Toolbar', 'mayosis' ),
        'archives' => __( 'EDD Archive Builder Archives', 'mayosis' ),
        'attributes' => __( 'EDD Archive Builder Attributes', 'mayosis' ),
        'parent_item_colon' => __( 'Parent EDD Archive Builder:', 'mayosis' ),
        'all_items' => __( 'EDD Archive Builder', 'mayosis' ),
        'add_new_item' => __( 'Add New EDD Archive Builder', 'mayosis' ),
        'add_new' => __( 'Add New', 'mayosis' ),
        'new_item' => __( 'New EDD Archive Builder', 'mayosis' ),
        'edit_item' => __( 'Edit EDD Archive Builder', 'mayosis' ),
        'update_item' => __( 'Update EDD Archive Builder', 'mayosis' ),
        'view_item' => __( 'View EDD Archive Builder', 'mayosis' ),
        'view_items' => __( 'View EDD Archive Builder', 'mayosis' ),
        'search_items' => __( 'Search EDD Archive Builder', 'mayosis' ),
        'not_found' => __( 'Not found', 'mayosis' ),
        'not_found_in_trash' => __( 'Not found in Trash', 'mayosis' ),
        'featured_image' => __( 'Featured Image', 'mayosis' ),
        'set_featured_image' => __( 'Set featured image', 'mayosis' ),
        'remove_featured_image' => __( 'Remove featured image', 'mayosis' ),
        'use_featured_image' => __( 'Use as featured image', 'mayosis' ),
        'insert_into_item' => __( 'Insert into EDD Archive Builder', 'mayosis' ),
        'uploaded_to_this_item' => __( 'Uploaded to this EDD Archive Builder', 'mayosis' ),
        'items_list' => __( 'EDD Archive Builder list', 'mayosis' ),
        'items_list_navigation' => __( 'EDD Archive Builder list navigation', 'mayosis' ),
        'filter_items_list' => __( 'Filter EDD Archive Builder list', 'mayosis' ),
    );
    $marchive_args = array(
        'label' => __( 'EDD Archive Builder', 'mayosis' ),
        'description' => __( '', 'mayosis' ),
        'labels' => $marchive_labels,
        'menu_icon' => '',
        'supports' => array('title', 'editor'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => false,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type( 'edd_archive_builder', $marchive_args );

}
add_action( 'init', 'mayosis_edd_archive_builder_cpt', 0 );


add_action('admin_menu', 'mayosis_fix_edd_archive_b_menu', 11);
function mayosis_fix_edd_archive_b_menu() {

// Add "Example CPT" Custom-Post-Type as submenu of the "Example Parent Page" page
    add_submenu_page('mayosis-admin-menu', 'Archive Builder', 'Archive Builder', 'edit_pages' , 'edit.php?post_type=edd_archive_builder');
}