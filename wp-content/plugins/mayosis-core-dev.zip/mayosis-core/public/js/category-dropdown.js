jQuery(document).ready(function ($) {
  $('#download_category').select2();
});
