<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class mayosis_edd_uneven_grid extends Widget_Base {

    public function get_name() {
        return 'mayosis-edd-uneven-grid';
    }

    public function get_title() {
        return __( 'Mayosis Uneven Grid', 'mayosis' );
    }
    public function get_categories() {
        return [ 'mayosis-ele-cat' ];
    }
    public function get_icon() {
        return 'eicon-elementor';
    }

    protected function _register_controls() {

        $this->add_control(
            'section_edd',
            [
                'label' => __( 'Mayosis Uneven Grid', 'mayosis' ),
                'type' => Controls_Manager::SECTION,
            ]
        );


        $this->add_control(
            'item_per_page',
            [
                'label'   => esc_html_x( 'Amount of item to display', 'Admin Panel', 'mayosis' ),
                'type'    => Controls_Manager::NUMBER,
                'default' =>  "10",
                'section' => 'section_edd',
            ]
        );

        $this->add_control(
            'category',
            array(
                'label'       => esc_html__( 'Select Categories', 'mayosis' ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'section' => 'section_edd',
                'options'     => array_flip(mayosis_items_extracts( 'categories', array(
                    'sort_order'  => 'ASC',
                    'taxonomy'    => 'download_category',
                    'hide_empty'  => false,
                ) )),
                'label_block' => true,
            )
        );

        $this->add_control(
            'categorynotin',
            [
                'label' => __( 'Exclude Category', 'mayosis' ),
                'description' => __('Add one category slug','mayosis'),
                'type' =>  Controls_Manager::SELECT2,
                'multiple'    => true,
                'options'     => array_flip(mayosis_items_extracts( 'categories', array(
                    'sort_order'  => 'ASC',
                    'taxonomy'    => 'download_category',
                    'hide_empty'  => false,
                ) )),
                'label_block' => true,
                'section' => 'section_edd',
            ]
        );

        $this->add_control(
            'tags',
            array(
                'label'       => esc_html__( 'Select Tags', 'mayosis' ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'section' => 'section_edd',
                'options'     => array_flip(mayosis_items_extracts( 'tags', array(
                    'sort_order'  => 'ASC',
                    'taxonomies'    => 'download_tag',
                    'hide_empty'  => false,
                ) )),
                'label_block' => true,
            )
        );



        $this->add_control(
            'order',
            [
                'label' => __( 'Order', 'mayosis' ),
                'type' => Controls_Manager::SELECT,
                'section' => 'section_edd',
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending'
                ],
                'default' => 'desc',

            ]
        );
        
        $this->add_control(
			'featured_product',
			[
				'label' => __( 'Featured', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Featured', 'your-plugin' ),
				'label_off' => __( 'Normal', 'your-plugin' ),
				'section' => 'section_edd',
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


        $this->start_controls_section(
            'other_style',
            [
                'label' => __( 'Style', 'mayosis' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
			'img-border-radius',
			[
				'label' => __( 'Small Image Border Radius', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mayosis-uv-common-slot .msuv-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'large-img-border-radius',
			[
				'label' => __( 'Large Image Border Radius', 'plugin-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mayosis-uv-middle-slot .msuv-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'smimage_box_shadow',
				'label' => __( 'Small Image Box Shadow', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .mayosis-uv-common-slot .msuv-thumbnail img',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'lgimage_box_shadow',
				'label' => __( 'Large Image Box Shadow', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .mayosis-uv-middle-slot .msuv-thumbnail img',
			]
		);


        $this->end_controls_section();

    }

    protected function render( $instance = [] ) {

        // get our input from the widget settings.

        $settings = $this->get_settings();
        $post_count = ! empty( $settings['item_per_page'] ) ? (int)$settings['item_per_page'] : 5;
        $categories= $settings['category'];
        $downloads_category_not=$settings['categorynotin'];
        $post_order_term=$settings['order'];
        $tags = $settings['tags'];
        $fproduct = $settings['featured_product'];
        
        ?>

        <div class="edd_recent_ark">

            <div class="mfull-undeven-grid-elementor">
                <div class="product--uneven--grid--elementor">

                    <?php
                    global $post;


                    if ($fproduct==="yes"){
                    $args = array( 'post_type' => 'download','posts_per_page' => $post_count, 'order' => (string) trim($post_order_term),'meta_key' => 'edd_feature_download' );
                    } else {
                        $args = array( 'post_type' => 'download','posts_per_page' => $post_count, 'order' => (string) trim($post_order_term), ); 
                    }

                    if(!empty($categories[0])) {
                        $args['tax_query'] = array(
                            array(
                                'taxonomy' => 'download_category',
                                'field'    => 'ids',
                                'terms'    => $categories
                            )
                        );
                    }

                    if(!empty($tags[0])) {
                        $args['tax_query'] = array(
                            array(
                                'taxonomy' => 'download_tag',
                                'field'    => 'ids',
                                'terms'    => $tags
                            )
                        );
                    }

                    if(!empty($downloads_category_not[0])) {
                        $args['tax_query'] = array(
                            array(
                                'taxonomy' => 'download_category',
                                'field'    => 'ids',
                                'terms'    => $downloads_category_not,
                                'operator' => 'NOT IN'
                            )
                        );
                    }
                    $the_query = new \WP_Query($args);

                    ?>
                    <div class="row mayosis-uv-style-product msuv-style-one">

                        <div class="col-12 col-md-4 mayosis-uv-common-slot">
                            <?php for ($i = 0; $i < 4; $i ++): $the_query -> the_post(); ?>

                                <div class="mayosis-uv-left-product">
                                    <div class="msuv-thumbnail">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                                <?php the_post_thumbnail('mayosis-uneven-left-small'); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php
                                if (!$the_query -> have_posts()) :
                                    break;
                                endif; ?>
                            <?php endfor; ?>
                        </div>

                        <div class="col-12 col-md-4 mayosis-uv-middle-slot">
                            <?php $mayosis_small_grid_count = $the_query -> post_count - 4;
                            if ($the_query -> have_posts() && $mayosis_small_grid_count > 0):
                                $posts_per_column = $post_count - 4; ?>

                                <?php for ($i = 0; $i < 1; $i++):

                                if (!$the_query -> have_posts()) :
                                    break;
                                endif;
                                $the_query -> the_post();
                                ?>
                                <div class="mayosis-uv-middle-product">
                                    <div class="msuv-thumbnail">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                                <?php the_post_thumbnail('mayosis-uneven-middle-large'); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endfor; ?>

                            <?php endif; ?>
                        </div>

                        <div class="col-12 col-md-4 mayosis-uv-common-slot">
                            <?php $mayosis_small_grid_count = $the_query -> post_count - 5;
                            if ($the_query -> have_posts() && $mayosis_small_grid_count > 0):
                                $posts_per_column = $post_count - 5; ?>

                                <?php for ($i = 0; $i < 4; $i++):

                                if (!$the_query -> have_posts()) :
                                    break;
                                endif;
                                $the_query -> the_post();
                                ?>
                                <div class="mayosis-uv-right-product">
                                    <div class="msuv-thumbnail">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                                <?php the_post_thumbnail('mayosis-uneven-left-small'); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endfor; ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php

    }

    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new mayosis_edd_uneven_grid );
?>