<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class mayosis_product_title extends Widget_Base {

   public function get_name() {
      return 'mayosis-product-title';
   }

   public function get_title() {
      return __( 'Mayosis Product Title', 'mayosis' );
   }
public function get_categories() {
		return [ 'mayosis-product-elements' ];
	}
   public function get_icon() { 
        return 'eicon-editor-h1';
   }

   protected function _register_controls() {
        $this->start_controls_section(
			'mayosis_product_title',
			[
				'label' => __( 'Product Title Style', 'mayosis' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		 $this->add_control(
                'product_title_html_tag',
                [
                    'label'   => __( 'Title HTML Tag', 'mayosis' ),
                    'type'    => Controls_Manager::SELECT,
                    'options' => mayosis_html_tag_lists(),
                    'default' => 'h1',
                ]
            );
            
              $this->add_responsive_control(
                'product_title_align',
                [
                    'label'        => __( 'Alignment', 'mayosis' ),
                    'type'         => Controls_Manager::CHOOSE,
                    'options'      => [
                        'left'   => [
                            'title' => __( 'Left', 'mayosis' ),
                            'icon'  => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'mayosis' ),
                            'icon'  => 'eicon-text-align-center',
                        ],
                        'right'  => [
                            'title' => __( 'Right', 'mayosis' ),
                            'icon'  => 'eicon-text-align-right',
                        ],
                    ],
                    'prefix_class' => 'elementor-align-%s',
                    'default'      => 'left',
                ]
            );
            
              $this->add_group_control(
                Group_Control_Typography::get_type(),
                array(
                    'name'      => 'product_title_typography',
                    'label'     => __( 'Typography', 'mayosis' ),
                    'selector'  => '{{WRAPPER}} .product_title',
                )
            );
            
            
            $this->add_control(
                'product_title_color',
                [
                    'label'     => __( 'Title Color', 'mayosis' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .product_title' => 'color: {{VALUE}} !important;',
                    ],
                ]
            );
            
             $this->add_responsive_control(
                'product_title_margin',
                [
                    'label' => __( 'Margin', 'mayosis' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .product_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    ],
                    'separator' => 'before',
                ]
            );
			
     $this->end_controls_section();
   }

   protected function render( $instance = [] ) {

      // get our input from the widget settings.

       $settings = $this->get_settings();
       
      ?>


<div class="mayosis-single-p-title">
 <?php
 if( Plugin::instance()->editor->is_edit_mode() ){
            $title = get_the_title( mayosis_get_last_product_id() );
            echo sprintf( "<%s class='product_title entry-title'>%s</%s>", $settings['product_title_html_tag'], $title, $settings['product_title_html_tag'] );
        }else{
            echo sprintf( "<%s class='product_title entry-title'>%s</%s>", $settings['product_title_html_tag'], get_the_title(), $settings['product_title_html_tag']  );
        }
 ?>
</div>
	


      <?php

   }

   protected function content_template() {}

   public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new mayosis_product_title);
?>